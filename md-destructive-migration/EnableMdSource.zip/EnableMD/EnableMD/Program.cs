﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.IO;
using Newtonsoft.Json.Linq;


namespace EnableMD
{
    /// <summary>
    /// This application will modify an exported Resource Group template to enable the Azure Managed Disk service. 
    /// To understand the flow, please first read through the EnableManagedDisks.ps1 script.
    /// </summary>
    class Program
    {
        struct MdNode
        {
            public JToken vm;
            public JObject mdJson;
        }
        static void Main(string[] args)
        {
            try
            {
                // two parameters are required for this app. 1. The filename of the template. 2. A list of VMs and OS type of each VM deliminated by '|' and ','.
                var file = System.IO.File.OpenText(args[0]);   // filename to open
                string vmlist = args[1];    // vmname|ostype -- example: vw000598|Linux,vw000333|Windows

                NameValueCollection vmList2 = new NameValueCollection();
                string[] vms = vmlist.Split(',');
                foreach (string vm in vms)
                {
                    string[] pair = vm.Split('|');
                    vmList2.Add(pair[0], pair[1]);
                }

                List<MdNode> mdResources = new List<MdNode>();
                JObject root = JObject.Parse(file.ReadToEnd());
                var resources = root["resources"];
                var jsonparameters = root["parameters"];

                foreach (JToken resource in resources.Children())
                {
                    string resourceType = (string)resource["type"];

                    if (resourceType == "Microsoft.Compute/availabilitySets")
                    {
                        JToken prop = resource["properties"];
                   //     prop["platformFaultDomainCount"] = 2;   // TODO: TEST THIS !!!!
                   //     prop["platformUpdateDomainCount"] = 5;
                        prop.First.AddBeforeSelf(new JProperty("managed", true));

                        resource["apiVersion"] = "2016-04-30-preview";
                    }
                    else if (resourceType == "Microsoft.Compute/virtualMachines")
                    {
                        ///
                        // first -- modify the osDisk properties
                        ///

                        // Important Assumption: any VM of type S -- i.e. DS series -- will use Premium Storage. However, an S series VM can still use Standard Storage. This may need to be tweaked.
                        bool isPremiumStorage = false;
                        string vmSize = (string)resource["properties"]["hardwareProfile"]["vmSize"];
                        if (vmSize.StartsWith("Standard_") && vmSize.Substring(10, 1) == "S")
                            isPremiumStorage = true;

                        // Remove the imageReference property if it exists for a VM created from a gallery image
                        JToken storageProfile = resource["properties"]["storageProfile"];
                        JProperty imageReference = storageProfile.Children<JProperty>().FirstOrDefault(p => p.Name == "imageReference");
                        if (imageReference != null)
                            imageReference.Remove();

                        // Change the createOption to Attach as we're attaching to the existing disks to import them to MD
                        JToken osDisk = resource["properties"]["storageProfile"]["osDisk"];
                        osDisk["createOption"] = "Attach";

                        // set the osType property to Windows or Linux
                        bool windows = false;
                        string vmNameToken = (string)resource["name"];
                        vmNameToken = vmNameToken.Substring(13);
                        vmNameToken = vmNameToken.Substring(0, vmNameToken.Length - 3);
                        JToken vmNameToken2 = jsonparameters[vmNameToken]["defaultValue"];
                        string vmName = (string)vmNameToken2;
                        //if (resource["properties"]["osProfile"] != null && resource["properties"]["osProfile"]["linuxConfiguration"] != null)
                        if (vmList2[vmName] == "Linux")
                        {
                            osDisk.First.AddBeforeSelf(new JProperty("osType", "Linux"));
                            windows = false;
                        }
                        else
                        {
                            // window VM        
                            osDisk.First.AddBeforeSelf(new JProperty("osType", "Windows"));
                            windows = true;
                        }

                        JToken osdiskVhd = osDisk["vhd"];
                        JToken osdiskName = osDisk["name"];

                        // Add the Managed Disk resource
                        AddMD(resource, (string)osdiskName, (string)osdiskVhd["uri"], "128", isPremiumStorage, mdResources);

                        // Link the Managed Disk resource into the VM resource
                        LinkMD(osDisk, osdiskName, resource);

                        ///
                        // second -- modify all of the data disks
                        ///
                        JArray dataDisks = (JArray)resource["properties"]["storageProfile"]["dataDisks"];
                        if (dataDisks != null)
                        {
                            foreach (JToken dataDisk in dataDisks.Children())
                            {
                                JToken dataVhd = dataDisk["vhd"];
                                JToken dataDiskName = dataDisk["name"];
                                JToken dataDiskSize = dataDisk["diskSizeGB"];

                                // Change the createOption to Attach as we're attaching to the existing disks to import them to MD
                                dataDisk["createOption"] = "Attach";

                                // Add the Managed Disk resource
                                AddMD(resource, (string)dataDiskName, (string)dataVhd["uri"], (string)dataDiskSize, isPremiumStorage, mdResources);

                                // Link the Managed Disk resource into the VM resource
                                LinkMD(dataDisk, dataDiskName, resource);

                                JProperty size = dataDisk.Children<JProperty>().FirstOrDefault(p => p.Name == "diskSizeGB");
                                if (size != null)
                                    size.Remove();
                            }
                        }

                        ///
                        // Third -- remove the osProfile property
                        ///
                        if (windows)
                        {
                            JProperty osProfile = resource["properties"].Children<JProperty>().FirstOrDefault(p => p.Name == "osProfile");
                            if (osProfile != null)
                                osProfile.Remove();
                        }

                        ///
                        // Fourth -- set the api version of the VM resource
                        ///
                        resource["apiVersion"] = "2016-04-30-preview";
                    }
                    /*else if (resourceType == "Microsoft.Network/publicIPAddresses")
                    {
                        // lowercase the domainnamelabel
                        JToken prop = resource["properties"];
                        if (prop["dnsSettings"] != null && prop["dnsSettings"]["domainNameLabel"] != null)
                        {
                            prop["dnsSettings"]["domainNameLabel"] = ((string)prop["dnsSettings"]["domainNameLabel"]).ToLower();
                        }
                    }*/
                }

                // Add in the Managed Disk resources
                foreach (MdNode disk in mdResources)
                {
                    disk.vm.AddBeforeSelf(disk.mdJson);
                }

                // Remove these 3 parameters that get created for each Windows VM as the osProfile that references these is now removed for windows VMs 
                var parameters = root["parameters"];
                List<JToken> itemsToRemove = new List<JToken>();
                NameValueCollection itemsToReplaceList = new NameValueCollection();

                foreach (JToken parameter in parameters.Children())
                {
                    string param = (string)(parameter.Path);

                    if ((param.EndsWith("_computerName")) || (param.EndsWith("_adminUsername")) || (param.EndsWith("_adminPassword")))
                    {
                        // remove these paramters because their values are null and not used
                        itemsToRemove.Add(parameter);
                    }
                    else
                    {
                        // replace the parameter value into the json, and remove the paramter
                        string n = (string)(parameter.Path);
                        n = n.Substring(11, n.Length - 11);
                        string pp = "";
                        int i = 0;
                        foreach (JToken p in parameter.Values())
                        {
                            pp = (string)p;
                            if (i == 0) break;
                        }

                        itemsToReplaceList.Add(n, pp);
                        itemsToRemove.Add(parameter);
                    }
                }

                foreach (JToken parameter in itemsToRemove)
                    parameter.Remove();

                string paramReplacedJson = root.ToString();
                foreach (string item in itemsToReplaceList.Keys)
                {
                    string find = "parameters('" + item + "')";
                    string replace = "'" + itemsToReplaceList[item] + "'";
                    paramReplacedJson = paramReplacedJson.Replace(find, replace);
                }

                // Finally, write out the new modified json file to the default folder
                File.WriteAllText("MD_" + args[0], paramReplacedJson);
                file.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occurred in EnableMD.\n{0} \n{1}", e.Message, e.StackTrace);
                Console.WriteLine("Parameters:\n{0} \n{1}", args[0], args[1]);
            }
        }

        static void AddMD(JToken node, string name, string url, string diskSize, bool isPremiumStorage, List<MdNode> disks)
        {
            string json = @"
{{ 
	    ""type"": ""Microsoft.Compute/disks"",
        ""name"": ""{0}"",
		""apiVersion"": ""2016-04-30-preview"",
        ""location"": ""[resourceGroup().location]"",    
		""properties"": 
		{{ 
			""creationData"": 
			{{
				""createOption"": ""Import"",
				""sourceUri"": ""{1}"" 
			}},
			""accountType"": ""{3}"",
			""diskSizeGB"": ""{2}""
		}}	
	}}
";
            string diskResource = string.Format(json, name, url, diskSize, (isPremiumStorage ? "Premium_LRS" : "Standard_LRS"));
            var newMDisk = JObject.Parse(diskResource);

            MdNode md = new MdNode();
            md.vm = node;
            md.mdJson = newMDisk;
            
            disks.Add(md);
        }

        static void LinkMD(JToken osDisk, JToken name, JToken resource)
        {
            // Replace vhd property with managedDisk property
            string name2 = (string)name;
            name2 = name2.Substring(1, name2.Length - 2);
            string nameResource = string.Format("[resourceId('Microsoft.Compute/disks', {0})]", name2);
            osDisk.First.AddAfterSelf(new JProperty("managedDisk", new JObject(new JProperty("id", nameResource))));

            JProperty vhd = osDisk.Children<JProperty>().FirstOrDefault(p => p.Name == "vhd");
            if (vhd != null)
                vhd.Remove();

            // Now add dependency to MD resource to VM resource
            JArray depends = (JArray) resource["dependsOn"];
            depends.Add(nameResource);
        }
    }
}
